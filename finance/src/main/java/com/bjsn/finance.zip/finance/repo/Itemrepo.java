package com.bjsn.finance.repo;

import com.bjsn.finance.Module.Item;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface Itemrepo extends JpaRepository<Item,Integer> {
    List<Item> findByReminderDate(LocalDate date);
    List<Item> findByType(String type);
    List<Item> findByCategory(String category);
    List<Item> findByTypeAndCategory(String type, String category);
}
